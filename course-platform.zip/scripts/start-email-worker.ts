import "../workers/email-worker"

console.log("Email worker started")

