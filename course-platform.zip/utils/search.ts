import type { Course } from "@/types/course"

export function searchCourses(
  courses: Course[],
  query: string,
  filters: {
    category?: string
    level?: string
    minPrice?: number
    maxPrice?: number
  },
): Course[] {
  return courses.filter((course) => {
    const matchesQuery =
      course.title.toLowerCase().includes(query.toLowerCase()) ||
      course.description.toLowerCase().includes(query.toLowerCase())

    const matchesCategory = !filters.category || course.category === filters.category
    const matchesLevel = !filters.level || course.level === filters.level
    const matchesPrice =
      (!filters.minPrice || course.price >= filters.minPrice) && (!filters.maxPrice || course.price <= filters.maxPrice)

    return matchesQuery && matchesCategory && matchesLevel && matchesPrice
  })
}

