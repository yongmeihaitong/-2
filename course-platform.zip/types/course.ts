export interface Course {
  id: string
  title: string
  description: string
  price: number
  duration: string
  students: number
  level: string
  imageUrl: string
  slug: string
  category: string
}

