"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"

interface VideoLessonProps {
  title: string
  videoUrl: string
  courseId: string
  id: string
  course: { id: string }
}

export function VideoLesson({ title, videoUrl, courseId, id, course }: VideoLessonProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [completed, setCompleted] = useState(false)

  const updateProgress = async () => {
    const response = await fetch("/api/progress", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        courseId: course.id,
        lessonId: id,
        completed: true,
      }),
    })
    if (response.ok) {
      setCompleted(true)
    }
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">{title}</h2>
      <div className="aspect-video bg-gray-200 relative">
        {isPlaying ? (
          <iframe
            className="w-full h-full"
            src={`${videoUrl}?autoplay=1`}
            allow="autoplay; encrypted-media"
            allowFullScreen
          ></iframe>
        ) : (
          <div className="absolute inset-0 flex items-center justify-center">
            <Button onClick={() => setIsPlaying(true)}>Play Video</Button>
          </div>
        )}
      </div>
      <Button onClick={updateProgress} disabled={completed} className="mt-4">
        {completed ? "Completed" : "Mark as Completed"}
      </Button>
    </div>
  )
}

