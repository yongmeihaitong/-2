import { emailQueue } from "../lib/queue"
import { sendEmail } from "../lib/email"

emailQueue.process("verification", async (job) => {
  await sendEmail(job.data)
})

emailQueue.process("welcome", async (job) => {
  await sendEmail(job.data)
})

emailQueue.on("completed", (job) => {
  console.log(`Job ${job.id} completed`)
})

emailQueue.on("failed", (job, err) => {
  console.error(`Job ${job.id} failed with error: ${err.message}`)
})

